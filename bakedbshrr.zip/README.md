# bakedbshrr Restaurant Agent

This folder holds the restaurant menu data for bakedbshrr.

## Files
- `menu.json` — current menu data

## Next step
We can build a Zo Space page or API route on top of this data so you can:
- view the menu
- translate ingredient lists
- change prices
- add plates
- remove plates
